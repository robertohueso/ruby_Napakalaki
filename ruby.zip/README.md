# Napakalaki

## Versión Ruby
Práctica para la asignatura Programación y Diseño orientado a objetos - UGR 2015/2016.

**Por Roberto Hueso Gómez**
