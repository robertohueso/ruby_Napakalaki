#EXAMEN
require_relative "Examen"
examen = NapakalakiGame::Examen.new
examen.run
#FIN EXAMEN
