require_relative "p2"

P2::P2.examen
