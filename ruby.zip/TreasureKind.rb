#encoding: utf-8
module NapakalakiGame
module TreasureKind
   ARMOR = :armor
   ONEHAND = :onehand
   BOTHHANDS = :bothhands
   HELMET = :helmet
   SHOES = :shoes
end
end
