#encoding: utf-8
module NapakalakiGame
module CombatResult
   WINGAME = :wingame
   WIN = :win
   LOSE = :lose
end
end
